public class Warga {
    String nama;
    String type; // zakat / sedekah
    boolean isBeras;
    Integer nominal;

}
